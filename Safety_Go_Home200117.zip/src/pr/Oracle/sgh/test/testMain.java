package pr.Oracle.sgh.test;

import static org.junit.Assert.assertEquals;

import pr.Oracle.sgh.model.MemberDTO;
import pr.Oracle.sgh.service.MainFunction;
import pr.Oracle.sgh.service.UserFunction;

public class testMain {

	public static void main(String[] args) {
		MemberDTO user = new MemberDTO("test", true, "user","�̸�");
		MainFunction function = new MainFunction(new UserFunction(), user);
		System.out.println("���� Ÿ�� : " + function.getType());
		System.out.println("���� id : " + function.getId());
		function.changeType("viewer");
		System.out.println("Ÿ�� �ٲ� : " + function.getType());
		System.out.println("���� �̸� : " + function.getName());
		System.out.println("�Ͱ����α׷� " + function.start());
		
		System.out.println(function.startChat());
		
		
		
		
		System.out.println(function.endChat());
		
		System.out.println("�Ͱ����α׷� " + function.end());
		
		
		
		assertEquals("chat start",function.startChat());
		assertEquals("chat end", function.endChat());
		
	}

}
