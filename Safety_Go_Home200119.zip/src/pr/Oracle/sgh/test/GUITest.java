package pr.Oracle.sgh.test;

import pr.Oracle.sgh.GUI.GUI_Main;
import pr.Oracle.sgh.GUI.GUI_Main_New;

public class GUITest {

	public static final int SCREEN_WIDTH = 478;
	public static final int SCREEN_HEIGHT = 686;
	public static int ISDOING = 0;

	public static void main(String[] args) {

//		new GUI_Accompany_Status();
//		new GUI_Frame_DEFEULT();

//		MapViewOptions options = new MapViewOptions();
//        options.importPlaces();
//        options.setApiKey("AIzaSyCmPGyPDj5ZmiCKPmtOQEkR2D_lP6eB6Vo");
//        final HelloWorld mapView = new HelloWorld(options);
//        JFrame frame = new JFrame("JxMaps - Hello, World!");
//
//        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
//        frame.add(mapView, BorderLayout.CENTER);
//        frame.setSize(700, 500);
//        frame.setLocationRelativeTo(null);
//        frame.setVisible(true);

//		new GUI_SignUp();
//		new GUI_Main();
//		new GUI_Frame_DEFEULT();

	}
}
